extends Control

# 引用节点
@onready var player_list: ItemList = $HSplitContainer/PlayerListPanel/VBoxContainer/PlayerList
@onready var chat_history: RichTextLabel = $HSplitContainer/ChatPanel/VBoxContainer/ChatHistory
@onready var message_line_edit: LineEdit = $HSplitContainer/ChatPanel/VBoxContainer/InputContainer/MessageLineEdit
@onready var send_button: Button = $HSplitContainer/ChatPanel/VBoxContainer/InputContainer/SendButton
@onready var disconnect_button: Button = $HSplitContainer/ChatPanel/VBoxContainer/InputContainer/DisconnectButton

func _ready() -> void:
	# 连接信号
	send_button.pressed.connect(_on_send_pressed)
	disconnect_button.pressed.connect(_on_disconnect_pressed)
	message_line_edit.text_submitted.connect(_on_message_submitted)

	# 连接聊天管理器信号
	ChatManager.player_joined.connect(_on_player_joined)
	ChatManager.player_left.connect(_on_player_left)
	ChatManager.chat_message_received.connect(_on_chat_message_received)
	ChatManager.system_message_received.connect(_on_system_message_received)
	ChatManager.lobby_updated.connect(_on_lobby_updated)

	# 连接网络断开信号
	NetworkManager.server_disconnected.connect(_on_server_disconnected)

	# 初始化玩家列表
	_update_player_list()

	# 聚焦输入框
	message_line_edit.grab_focus()

	# 添加欢迎消息
	_add_system_message("欢迎来到聊天室！")

## 发送消息
func _on_send_pressed() -> void:
	_send_message()

## 消息提交（回车）
func _on_message_submitted(message: String) -> void:
	_send_message()

## 发送消息逻辑
func _send_message() -> void:
	var message: String = message_line_edit.text.strip_edges()
	if message.is_empty():
		return

	NetworkManager.send_chat_message(message)
	message_line_edit.clear()

## 断开连接
func _on_disconnect_pressed() -> void:
	NetworkManager.disconnect_from_server()
	get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")

## 玩家加入回调
func _on_player_joined(peer_id: int, player_name: String) -> void:
	_update_player_list()

## 玩家离开回调
func _on_player_left(peer_id: int, player_name: String) -> void:
	_update_player_list()

## 聊天消息回调
func _on_chat_message_received(peer_id: int, player_name: String, message: String) -> void:
	var display_name := player_name if peer_id != NetworkManager.get_local_peer_id() else "你"
	chat_history.append_text("[%s] %s: %s\n" % [_get_time_string(), display_name, message])
	_scroll_to_bottom()

## 系统消息回调
func _on_system_message_received(message: String) -> void:
	_add_system_message(message)

## 大厅更新回调
func _on_lobby_updated(players: Dictionary) -> void:
	_update_player_list()

## 服务器断开回调
func _on_server_disconnected() -> void:
	_add_system_message("已与服务器断开连接")
	await get_tree().create_timer(1.5).timeout
	get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")

## 更新玩家列表
func _update_player_list() -> void:
	player_list.clear()
	var players: Dictionary = NetworkManager.get_players()

	for peer_id in players.keys():
		var player_name: String = players[peer_id]
		var prefix := "● " if peer_id == NetworkManager.get_local_peer_id() else "  "
		var host_tag := " [主机]" if peer_id == 1 and NetworkManager.is_host() else ""
		player_list.add_item(prefix + player_name + host_tag)

## 添加系统消息
func _add_system_message(message: String) -> void:
	chat_history.append_text("[%s] [系统] %s\n" % [_get_time_string(), message])
	_scroll_to_bottom()

## 滚动到底部
func _scroll_to_bottom() -> void:
	chat_history.scroll_to_line(chat_history.get_line_count() - 1)

## 获取时间字符串
func _get_time_string() -> String:
	var time := Time.get_time_dict_from_system()
	return "%02d:%02d:%02d" % [time.hour, time.minute, time.second]
