extends Node

# 大厅玩家数据
var lobby_players: Dictionary = {}

# 信号
signal player_joined(peer_id: int, player_name: String)
signal player_left(peer_id: int, player_name: String)
signal chat_message_received(peer_id: int, player_name: String, message: String)
signal system_message_received(message: String)
signal lobby_updated(players: Dictionary)

## RPC: 请求加入大厅（客户端发送，服务器处理）
@rpc("any_peer", "call_local", "reliable")
func request_join_lobby(player_name: String) -> void:
	# 只有服务器执行以下逻辑
	if not multiplayer.is_server():
		return

	var sender_id := multiplayer.get_remote_sender_id()

	if not lobby_players.has(sender_id):
		lobby_players[sender_id] = player_name
		player_joined.emit(sender_id, player_name)
		lobby_updated.emit(lobby_players)

		# 通知其他客户端有新玩家加入
		notify_player_joined.rpc_id(sender_id, player_name)
		# 将当前大厅玩家列表同步给新玩家
		sync_lobby_state.rpc_id(sender_id, lobby_players)

## RPC: 通知其他客户端有新玩家加入
@rpc("authority", "call_remote", "reliable")
func notify_player_joined(peer_id: int, player_name: String) -> void:
	if not lobby_players.has(peer_id):
		lobby_players[peer_id] = player_name
		player_joined.emit(peer_id, player_name)
		lobby_updated.emit(lobby_players)
		# 发送系统消息
		system_message_received.emit("%s 加入了聊天室" % player_name)

## RPC: 同步大厅状态给新玩家
@rpc("authority", "call_remote", "reliable")
func sync_lobby_state(players: Dictionary) -> void:
	# 新玩家收到服务器发送的当前玩家列表，覆盖本地
	lobby_players = players
	lobby_updated.emit(lobby_players)

## RPC: 客户端发送聊天消息到服务器
@rpc("any_peer", "call_local", "reliable")
func receive_message_from_client(message: String) -> void:
	if not multiplayer.is_server():
		return
	var sender_id := multiplayer.get_remote_sender_id()
	var player_name: String = lobby_players.get(sender_id, "未知")
	# 服务器广播给所有客户端
	broadcast_chat_message.rpc(sender_id, player_name, message)

## RPC: 聊天消息（广播）
@rpc("authority", "call_local", "reliable")
func broadcast_chat_message(peer_id: int, player_name: String, message: String) -> void:
	chat_message_received.emit(peer_id, player_name, message)

## RPC: 系统消息（广播）
@rpc("authority", "call_local", "reliable")
func broadcast_system_message(message: String) -> void:
	system_message_received.emit(message)

## 添加玩家到大厅
func add_player_to_lobby(peer_id: int, player_name: String) -> void:
	lobby_players[peer_id] = player_name
	player_joined.emit(peer_id, player_name)
	lobby_updated.emit(lobby_players)

## 从大厅移除玩家
func remove_player_from_lobby(peer_id: int) -> String:
	var player_name: String = lobby_players.get(peer_id, "")
	if player_name != "":
		lobby_players.erase(peer_id)
		player_left.emit(peer_id, player_name)
		lobby_updated.emit(lobby_players)
	return player_name

## 获取大厅玩家列表
func get_lobby_players() -> Dictionary:
	return lobby_players.duplicate()

## 清空大厅
func clear_lobby() -> void:
	lobby_players.clear()
	lobby_updated.emit(lobby_players)

## 发送聊天消息
func broadcast_message(player_name: String, message: String) -> void:
	receive_message_from_client.rpc(message)

## 发送系统消息
func send_system_message(message: String) -> void:
	broadcast_system_message.rpc(message)
