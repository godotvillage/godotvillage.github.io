extends Node

# 网络配置
const DEFAULT_PORT := 3000
const MAX_PLAYERS := 32

# 连接状态
enum ConnectionState {
	DISCONNECTED,
	HOSTING,
	CONNECTED
}

var current_state: ConnectionState = ConnectionState.DISCONNECTED
var username: String = "Player"
var server_info: Dictionary = {}

# 信号定义
signal connection_succeeded()
signal connection_failed()
signal server_disconnected()
signal peer_connected(peer_id: int)
signal peer_disconnected(peer_id: int)
signal state_changed(state: ConnectionState)

func _ready() -> void:
	# 初始化多人连接信号
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.peer_connected.connect(_on_peer_connected)

## 创建服务器（主机）
func create_server(port: int, player_name: String) -> bool:
	username = player_name

	var peer := ENetMultiplayerPeer.new()
	var error := peer.create_server(port, MAX_PLAYERS)

	if error != OK:
		push_error("创建服务器失败: %s" % error)
		return false

	multiplayer.multiplayer_peer = peer
	current_state = ConnectionState.HOSTING
	state_changed.emit(current_state)

	# 主机自己加入大厅
	ChatManager.add_player_to_lobby(1, username)
	ChatManager.send_system_message("%s 创建了聊天室" % username)

	connection_succeeded.emit()
	return true

## 加入服务器（客户端）
func join_server(ip: String, port: int, player_name: String) -> bool:
	username = player_name

	var peer := ENetMultiplayerPeer.new()
	var error := peer.create_client(ip, port)

	if error != OK:
		push_error("连接服务器失败: %s" % error)
		return false

	multiplayer.multiplayer_peer = peer

	return true

## 断开连接
func disconnect_from_server() -> void:
	if current_state == ConnectionState.DISCONNECTED:
		return

	ChatManager.send_system_message("%s 离开了聊天室" % username)
	ChatManager.clear_lobby()

	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	current_state = ConnectionState.DISCONNECTED
	state_changed.emit(current_state)

## 发送聊天消息
func send_chat_message(message: String) -> void:
	if current_state == ConnectionState.DISCONNECTED:
		return

	ChatManager.broadcast_message(username, message)

## 获取玩家列表
func get_players() -> Dictionary:
	return ChatManager.get_lobby_players()

## 获取本地玩家ID
func get_local_peer_id() -> int:
	return multiplayer.get_unique_id()

## 是否是主机
func is_host() -> bool:
	return current_state == ConnectionState.HOSTING

## 回调：连接成功
func _on_connected_to_server() -> void:
	current_state = ConnectionState.CONNECTED
	state_changed.emit(current_state)
	# 发送加入消息
	ChatManager.request_join_lobby.rpc_id(1, username)
	connection_succeeded.emit()

## 回调：连接失败
func _on_connection_failed() -> void:
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	current_state = ConnectionState.DISCONNECTED
	state_changed.emit(current_state)
	connection_failed.emit()

## 回调：服务器断开
func _on_server_disconnected() -> void:
	ChatManager.clear_lobby()
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	current_state = ConnectionState.DISCONNECTED
	state_changed.emit(current_state)
	server_disconnected.emit()

## 回调：其他玩家连接（服务器端）
func _on_peer_connected(peer_id: int) -> void:
	# 服务器收到新玩家连接，等待玩家发送 request_join_lobby
	peer_connected.emit(peer_id)

## 回调：玩家断开
func _on_peer_disconnected(peer_id: int) -> void:
	# 只有服务器执行玩家移除逻辑
	if not multiplayer.is_server():
		return

	var player_name := ChatManager.remove_player_from_lobby(peer_id)
	if player_name != "":
		ChatManager.send_system_message("%s 离开了聊天室" % player_name)
	peer_disconnected.emit(peer_id)
