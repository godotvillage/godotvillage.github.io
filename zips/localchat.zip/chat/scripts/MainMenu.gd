extends Control

# 引用节点
@onready var username_line_edit: LineEdit = $PanelContainer/VBoxContainer/UsernameSection/UsernameLineEdit
@onready var host_port_spinbox: SpinBox = $PanelContainer/VBoxContainer/HostSection/HostPortSpinBox
@onready var host_button: Button = $PanelContainer/VBoxContainer/HostSection/HostButton
@onready var ip_line_edit: LineEdit = $PanelContainer/VBoxContainer/JoinSection/IPLineEdit
@onready var join_port_spinbox: SpinBox = $PanelContainer/VBoxContainer/JoinSection/JoinPortSpinBox
@onready var join_button: Button = $PanelContainer/VBoxContainer/JoinSection/JoinButton
@onready var status_label: Label = $PanelContainer/VBoxContainer/StatusLabel

func _ready() -> void:
	# 连接按钮信号
	host_button.pressed.connect(_on_host_pressed)
	join_button.pressed.connect(_on_join_pressed)

	# 连接网络信号
	NetworkManager.connection_succeeded.connect(_on_connection_succeeded)
	NetworkManager.connection_failed.connect(_on_connection_failed)

	# 默认用户名
	username_line_edit.text = "玩家" + str(randi() % 1000)

## 创建服务器
func _on_host_pressed() -> void:
	var username: String = username_line_edit.text.strip_edges()
	if username.is_empty():
		status_label.text = "请输入用户名"
		return

	var port: int = int(host_port_spinbox.value)

	status_label.text = "正在创建服务器..."
	host_button.disabled = true
	join_button.disabled = true

	if NetworkManager.create_server(port, username):
		_load_lobby()
	else:
		status_label.text = "创建服务器失败"
		host_button.disabled = false
		join_button.disabled = false

## 加入服务器
func _on_join_pressed() -> void:
	var username: String = username_line_edit.text.strip_edges()
	if username.is_empty():
		status_label.text = "请输入用户名"
		return

	var ip: String = ip_line_edit.text.strip_edges()
	if ip.is_empty():
		ip = "127.0.0.1"

	var port: int = int(join_port_spinbox.value)

	status_label.text = "正在连接服务器..."
	host_button.disabled = true
	join_button.disabled = true

	NetworkManager.join_server(ip, port, username)

## 连接成功
func _on_connection_succeeded() -> void:
	_load_lobby()

## 连接失败
func _on_connection_failed() -> void:
	status_label.text = "连接服务器失败"
	host_button.disabled = false
	join_button.disabled = false

## 加载大厅场景
func _load_lobby() -> void:
	var tree := get_tree()
	if tree:
		tree.change_scene_to_file("res://scenes/Lobby.tscn")
